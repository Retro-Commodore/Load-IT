*.drl = drill list, import this first in gc-preview (file type will be unrecognised, select 'drill rack')
*.drd = drill data, location of the drill holes
*.cmp = component side metal
*.sol = solder side metal
*.stc = mask stop for component side
*.sts = mask stop for solder side
*.plc = silkscreen for component side.